import React from "react";

function MyComponent() {
    return <h1>Hello, world!</h1>;
  }
  